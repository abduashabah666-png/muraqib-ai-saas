from flask import Flask,render_template,request,redirect,url_for,flash,session,jsonify
from werkzeug.security import generate_password_hash,check_password_hash
from werkzeug.utils import secure_filename
from datetime import datetime
import sqlite3,os
BASE=os.path.dirname(__file__); DB=os.path.join(BASE,'saas.db'); UP=os.path.join(BASE,'uploads'); os.makedirs(UP,exist_ok=True)
app=Flask(__name__); app.secret_key=os.getenv('SECRET_KEY','change-in-production'); ALLOWED={'pdf','png','jpg','jpeg','xlsx','xls','csv'}
def db():
 c=sqlite3.connect(DB); c.row_factory=sqlite3.Row; return c
def init_db():
 c=db(); c.executescript('''CREATE TABLE IF NOT EXISTS companies(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,plan TEXT DEFAULT 'trial',created_at TEXT NOT NULL); CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY AUTOINCREMENT,company_id INTEGER NOT NULL,name TEXT NOT NULL,email TEXT UNIQUE NOT NULL,password_hash TEXT NOT NULL,role TEXT DEFAULT 'admin',created_at TEXT NOT NULL); CREATE TABLE IF NOT EXISTS invoices(id INTEGER PRIMARY KEY AUTOINCREMENT,company_id INTEGER NOT NULL,filename TEXT NOT NULL,invoice_number TEXT,supplier TEXT,amount REAL DEFAULT 0,vat REAL DEFAULT 0,status TEXT DEFAULT 'بانتظار التحليل',risk TEXT DEFAULT 'غير محدد',created_at TEXT NOT NULL);'''); c.commit(); c.close()
def user():
 if 'user_id' not in session:return None
 c=db(); u=c.execute('SELECT * FROM users WHERE id=?',(session['user_id'],)).fetchone(); c.close(); return u
@app.route('/')
def home():
 u=user()
 if not u:return redirect(url_for('login'))
 c=db(); rows=c.execute('SELECT * FROM invoices WHERE company_id=? ORDER BY id DESC',(u['company_id'],)).fetchall(); stats=c.execute('SELECT COUNT(*) n,COALESCE(SUM(amount),0) total,COALESCE(SUM(vat),0) vat FROM invoices WHERE company_id=?',(u['company_id'],)).fetchone(); risks=c.execute("SELECT COUNT(*) n FROM invoices WHERE company_id=? AND risk='مرتفع'",(u['company_id'],)).fetchone()['n']; company=c.execute('SELECT * FROM companies WHERE id=?',(u['company_id'],)).fetchone(); c.close(); return render_template('dashboard.html',user=u,company=company,invoices=rows,stats=stats,risks=risks)
@app.route('/register',methods=['GET','POST'])
def register():
 if request.method=='POST':
  company=request.form['company'].strip(); name=request.form['name'].strip(); email=request.form['email'].strip().lower(); pw=request.form['password']
  if len(pw)<8: flash('كلمة المرور يجب أن تكون 8 أحرف على الأقل.','error'); return render_template('register.html')
  c=db(); now=datetime.now().isoformat(timespec='minutes')
  try:
   cid=c.execute('INSERT INTO companies(name,created_at) VALUES(?,?)',(company,now)).lastrowid; uid=c.execute('INSERT INTO users(company_id,name,email,password_hash,role,created_at) VALUES(?,?,?,?,?,?)',(cid,name,email,generate_password_hash(pw),'admin',now)).lastrowid; c.commit(); session['user_id']=uid; return redirect(url_for('home'))
  except sqlite3.IntegrityError: c.rollback(); flash('البريد الإلكتروني مستخدم بالفعل.','error')
  finally:c.close()
 return render_template('register.html')
@app.route('/login',methods=['GET','POST'])
def login():
 if request.method=='POST':
  email=request.form['email'].strip().lower(); pw=request.form['password']; c=db(); u=c.execute('SELECT * FROM users WHERE email=?',(email,)).fetchone(); c.close()
  if u and check_password_hash(u['password_hash'],pw): session['user_id']=u['id']; return redirect(url_for('home'))
  flash('بيانات الدخول غير صحيحة.','error')
 return render_template('login.html')
@app.route('/logout')
def logout(): session.clear(); return redirect(url_for('login'))
@app.route('/invoices',methods=['POST'])
def upload():
 u=user()
 if not u:return redirect(url_for('login'))
 f=request.files.get('file')
 if not f or not f.filename: flash('اختر ملفًا.','error'); return redirect(url_for('home'))
 ext=f.filename.rsplit('.',1)[-1].lower()
 if ext not in ALLOWED: flash('نوع الملف غير مدعوم.','error'); return redirect(url_for('home'))
 safe=f"{u['company_id']}_{datetime.now().strftime('%Y%m%d%H%M%S')}_{secure_filename(f.filename)}"; f.save(os.path.join(UP,safe)); c=db(); c.execute('INSERT INTO invoices(company_id,filename,created_at) VALUES(?,?,?)',(u['company_id'],safe,datetime.now().isoformat(timespec='minutes'))); c.commit(); c.close(); flash('تم استلام الفاتورة للتحليل.','success'); return redirect(url_for('home'))
@app.route('/api/invoices')
def api():
 u=user()
 if not u:return jsonify({'error':'unauthorized'}),401
 c=db(); rows=[dict(x) for x in c.execute('SELECT * FROM invoices WHERE company_id=? ORDER BY id DESC',(u['company_id'],)).fetchall()]; c.close(); return jsonify(rows)
if __name__=='__main__': init_db(); app.run(host='0.0.0.0',port=int(os.getenv('PORT',5000)),debug=True)
